//
//  ScrollViewDemoApp.swift
//  ScrollViewDemo
//
//  Created by Ivens Liao on 2024/11/18.
//

import SwiftUI

@main
struct ScrollViewDemoApp: SwiftUI.App {
    var body: some Scene {
        WindowGroup {
            AppStoreScrollView(apps: App.sampleApps)
        }
    }
}
