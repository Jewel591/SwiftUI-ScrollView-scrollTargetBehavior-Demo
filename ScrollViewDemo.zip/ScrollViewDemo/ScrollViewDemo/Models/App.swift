import Foundation

struct App: Identifiable {
    let id: UUID = UUID()
    let name: String
    let developer: String
    let iconName: String
    let category: String
    let price: Double
    let description: String
    let screenshots: [String]
    let rating: Double
    let reviews: Int
}

extension App {
    static let sampleApps = [
        App(
            name: "微信",
            developer: "Tencent Mobile International Limited",
            iconName: "wechat",
            category: "社交",
            price: 0.0,
            description: "微信是一款全球超过10亿人使用的通讯工具，支持发送语音、视频、图片和文字。",
            screenshots: ["wechat-1", "wechat-2", "wechat-3"],
            rating: 4.8,
            reviews: 498000
        ),
        App(
            name: "饿了么",
            developer: "Alibaba Local Services Limited",
            iconName: "eleme",
            category: "美食和饮品",
            price: 0.0,
            description: "饿了么-外卖食品配送平台，提供美食外卖订餐服务。",
            screenshots: ["eleme-1", "eleme-2", "eleme-3"],
            rating: 4.7,
            reviews: 235000
        ),
        App(
            name: "Bilibili",
            developer: "Bilibili Co., Ltd",
            iconName: "bilibili",
            category: "娱乐",
            price: 0.0,
            description: "bilibili是国内知名的视频弹幕网站，这里有最及时的动漫新番，最棒的ACG氛围。",
            screenshots: ["bili-1", "bili-2", "bili-3"],
            rating: 4.9,
            reviews: 892000
        ),
        App(
            name: "支付宝",
            developer: "Ant Financial Services Group",
            iconName: "alipay",
            category: "金融",
            price: 0.0,
            description: "支付宝是中国领先的移动支付平台，为用户提供安全、便捷的支付和生活服务。",
            screenshots: ["alipay-1", "alipay-2", "alipay-3"],
            rating: 4.8,
            reviews: 756000
        ),
        App(
            name: "网易云音乐",
            developer: "NetEase Inc.",
            iconName: "netease-music",
            category: "音乐",
            price: 0.0,
            description: "网易云音乐是一款专注于发现与分享的音乐产品，依托专业音乐人、DJ、好友推荐及社交功能。",
            screenshots: ["music-1", "music-2", "music-3"],
            rating: 4.9,
            reviews: 682000
        ),
        App(
            name: "小红书",
            developer: "Xiaohongshu Limited",
            iconName: "xiaohongshu",
            category: "生活方式",
            price: 0.0,
            description: "小红书是一个生活方式分享社区，用户可以发现美好生活灵感，分享时尚、美妆、美食等内容。",
            screenshots: ["xhs-1", "xhs-2", "xhs-3"],
            rating: 4.7,
            reviews: 523000
        )
    ]
} 