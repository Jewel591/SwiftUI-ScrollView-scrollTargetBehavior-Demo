import SwiftUI

struct AppStoreScrollView: View {
    let apps: [App]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // 今日推荐
                featuredSection

                // 热门应用
                popularAppsSection
            }
            .padding()
        }
    }

    private var featuredSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("今日推荐")
                .font(.title)
                .fontWeight(.bold)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 20) {
                    ForEach(apps) { app in
                        FeaturedAppCard(app: app)
                    }
                }
                .scrollTargetLayout()
            }
            .scrollTargetBehavior(.viewAligned)
        }
    }

    private var popularAppsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("热门应用")
                .font(.title)
                .fontWeight(.bold)

            ForEach(apps) { app in
                PopularAppRow(app: app)
            }
        }
    }
}

struct FeaturedAppCard: View {
    let app: App

    var body: some View {
        VStack(alignment: .leading) {
            // 应用截图
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.gray.opacity(0.2))
                .frame(width: 300, height: 200)
                .overlay(
                    Text(app.screenshots[0])
                        .foregroundColor(.gray)
                )

            HStack {
                // 应用图标
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.gray.opacity(0.2))
                    .frame(width: 40, height: 40)
                    .overlay(
                        Text(app.iconName)
                            .font(.caption)
                            .foregroundColor(.gray)
                    )

                VStack(alignment: .leading) {
                    Text(app.name)
                        .font(.headline)
                    Text(app.category)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }

                Spacer()

                Button(action: {}) {
                    Text(
                        app.price == 0
                            ? "获取" : "¥\(String(format: "%.2f", app.price))"
                    )
                    .fontWeight(.bold)
                    .foregroundColor(.blue)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 6)
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(16)
                }
            }
            .padding(.top, 8)
        }
        .frame(width: 300)
    }
}

struct PopularAppRow: View {
    let app: App

    var body: some View {
        HStack {
            // 应用图标
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.gray.opacity(0.2))
                .frame(width: 60, height: 60)
                .overlay(
                    Text(app.iconName)
                        .font(.caption)
                        .foregroundColor(.gray)
                )

            VStack(alignment: .leading, spacing: 4) {
                Text(app.name)
                    .font(.headline)
                Text(app.category)
                    .font(.caption)
                    .foregroundColor(.secondary)

                HStack {
                    Text(String(format: "%.1f", app.rating))
                    Text("(\(app.reviews))")
                }
                .font(.caption)
                .foregroundColor(.secondary)
            }

            Spacer()

            Button(action: {}) {
                Text(
                    app.price == 0
                        ? "获取" : "¥\(String(format: "%.2f", app.price))"
                )
                .fontWeight(.bold)
                .foregroundColor(.blue)
                .padding(.horizontal, 16)
                .padding(.vertical, 6)
                .background(Color.gray.opacity(0.2))
                .cornerRadius(16)
            }
        }
        .padding(.vertical, 8)
    }
}

#Preview {
    AppStoreScrollView(apps: App.sampleApps)
}
